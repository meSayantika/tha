import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales_agent',
  templateUrl: './sales_agent.component.html',
  styleUrls: ['./sales_agent.component.css']
})
export class Sales_agentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
